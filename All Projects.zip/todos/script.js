const Todo = (title, description, dueDate, priority) => {
  let completed = false;

  const toggleComplete = () => {
    completed = !completed;
  };

  return { title, description, dueDate, priority, completed, toggleComplete };
};

const Project = (name) => {
  let todos = [];

  const addTodo = (todo) => {
    todos.push(todo);
    Storage.saveProjects();
  };

  const removeTodo = (index) => {
    todos.splice(index, 1);
    Storage.saveProjects();
  };

  const getTodos = () => todos;

  return { name, addTodo, removeTodo, getTodos };
};

const Storage = (() => {
  const saveProjects = () => {
    const projects = App.getProjects().map(p => ({
      name: p.name,
      todos: p.getTodos().map(t => ({
        title: t.title,
        description: t.description,
        dueDate: t.dueDate,
        priority: t.priority,
        completed: t.completed
      }))
    }));
    localStorage.setItem("projects", JSON.stringify(projects));
  };

  const loadProjects = () => {
    const data = JSON.parse(localStorage.getItem("projects"));
    if (!data) return [];
    return data.map(p => {
      const project = Project(p.name);
      p.todos.forEach(t => {
        const todo = Todo(t.title, t.description, t.dueDate, t.priority);
        if (t.completed) todo.toggleComplete();
        project.addTodo(todo);
      });
      return project;
    });
  };

  return { saveProjects, loadProjects };
})();

const App = (() => {
  let projects = Storage.loadProjects();
  if (projects.length === 0) {
    projects.push(Project("Default"));
  }
  let currentProjectIndex = 0;

  const getProjects = () => projects;

  const getCurrentProject = () => projects[currentProjectIndex];

  const addProject = (name) => {
    projects.push(Project(name));
    currentProjectIndex = projects.length - 1;
    Storage.saveProjects();
    Display.renderProjects();
    Display.renderTodos();
  };

  const addTodo = (title, desc, dueDate, priority) => {
    const todo = Todo(title, desc, dueDate, priority);
    getCurrentProject().addTodo(todo);
    Display.renderTodos();
  };

  const removeTodo = (index) => {
    getCurrentProject().removeTodo(index);
    Display.renderTodos();
  };

  const setCurrentProject = (index) => {
    currentProjectIndex = index;
    Display.renderTodos();
  };

  return { getProjects, addProject, addTodo, removeTodo, getCurrentProject, setCurrentProject };
})();

const Display = (() => {
  const projectList = document.getElementById("project-list");
  const todoList = document.getElementById("todo-list");

  const renderProjects = () => {
    projectList.innerHTML = "";
    App.getProjects().forEach((project, idx) => {
      const li = document.createElement("li");
      li.textContent = project.name;
      li.addEventListener("click", () => {
        App.setCurrentProject(idx);
        renderProjects();
      });
      projectList.appendChild(li);
    });
  };

  const renderTodos = () => {
    todoList.innerHTML = "";
    const todos = App.getCurrentProject().getTodos();
    todos.forEach((todo, idx) => {
      const li = document.createElement("li");
      li.textContent = `${todo.title} (Due: ${todo.dueDate})`;
      li.classList.add(todo.priority);
      if (todo.completed) li.style.textDecoration = "line-through";
      li.addEventListener("click", () => {
        todo.toggleComplete();
        Storage.saveProjects();
        renderTodos();
      });
      li.addEventListener("dblclick", () => {
        App.removeTodo(idx);
      });
      todoList.appendChild(li);
    });
  };

  return { renderProjects, renderTodos };
})();

document.getElementById("add-project-btn").addEventListener("click", () => {
  const name = document.getElementById("new-project").value;
  if (name) App.addProject(name);
  document.getElementById("new-project").value = "";
});

document.getElementById("add-todo-btn").addEventListener("click", () => {
  const title = document.getElementById("todo-title").value;
  const desc = document.getElementById("todo-desc").value;
  const dueDate = document.getElementById("todo-due").value;
  const priority = document.getElementById("todo-priority").value;
  if (title && dueDate) {
    App.addTodo(title, desc, dueDate, priority);
  }
  document.getElementById("todo-title").value = "";
  document.getElementById("todo-desc").value = "";
  document.getElementById("todo-due").value = "";
});

Display.renderProjects();
Display.renderTodos();