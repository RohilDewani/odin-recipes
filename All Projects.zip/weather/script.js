const API_KEY = "9763ef0ad3f5f7c75ccef25c2ee285cf";

async function fetchWeather(location) {
  try {
    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${API_KEY}&units=metric`
    );
    const data = await response.json();
    if (data.cod !== 200) {
      console.error("Error:", data.message);
      return null;
    }
    console.log("Raw API data:", data);
    return data;
  } catch (error) {
    console.error("Fetch error:", error);
  }
}

function processWeatherData(data) {
  if (!data) return null;
  return {
    location: `${data.name}, ${data.sys.country}`,
    temperature: data.main.temp,
    feelsLike: data.main.feels_like,
    weather: data.weather[0].main,
    description: data.weather[0].description,
    icon: data.weather[0].icon,
    humidity: data.main.humidity,
    windSpeed: data.wind.speed
  };
}

function displayWeather(weather) {
  const container = document.getElementById("weather-display");
  container.innerHTML = "";
  if (!weather) {
    container.textContent = "Could not fetch weather data.";
    return;
  }

  const html = `
    <div class="weather-item"><strong>${weather.location}</strong></div>
    <div class="weather-item">Temperature: ${weather.temperature}°C</div>
    <div class="weather-item">Feels like: ${weather.feelsLike}°C</div>
    <div class="weather-item">Condition: ${weather.weather} (${weather.description})</div>
    <div class="weather-item">Humidity: ${weather.humidity}%</div>
    <div class="weather-item">Wind Speed: ${weather.windSpeed} m/s</div>
    <div class="weather-item">
      <img src="https://openweathermap.org/img/wn/${weather.icon}@2x.png" alt="icon">
    </div>
  `;
  container.innerHTML = html;
}

document.getElementById("location-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const location = document.getElementById("location-input").value;
  if (!location) return;

  const rawData = await fetchWeather(location);
  const weather = processWeatherData(rawData);
  console.log("Processed weather data:", weather);
  displayWeather(weather);
});