import time
 
print("Bell will ring every 10 seconds for 60 seconds using continue...")
 
for second in range(1, 61):

    if second % 10 == 0:

        print(f"🔔 Bell rings at {second} seconds")

        continue

    time.sleep(1)  # wait for 1 second
 