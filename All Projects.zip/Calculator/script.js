function add(a, b) {
  return a + b;
}
function subtract(a, b) {
  return a - b;
}
function multiply(a, b) {
  return a * b;
}
function divide(a, b) {
  if (b === 0) return "Can't divide by 0!";
  return a / b;
}

function operate(operator, a, b) {
  a = Number(a);
  b = Number(b);
  switch (operator) {
    case '+':
      return add(a, b);
    case '-':
      return subtract(a, b);
    case '*':
      return multiply(a, b);
    case '/':
      return divide(a, b);
    default:
      return null;
  }
}

const display = document.getElementById("display");
let firstNumber = "";
let secondNumber = "";
let currentOperator = null;
let shouldResetDisplay = false;

function updateDisplay(number) {
  if (display.textContent === "0" || shouldResetDisplay) {
    display.textContent = number;
    shouldResetDisplay = false;
  } else {
    display.textContent += number;
  }
}

document.querySelectorAll(".digit").forEach(button => {
  button.addEventListener("click", () => updateDisplay(button.textContent));
});

document.querySelectorAll(".operator").forEach(button => {
  button.addEventListener("click", () => setOperator(button.textContent));
});

document.querySelector(".equals").addEventListener("click", evaluate);
document.querySelector(".clear").addEventListener("click", clear);
document.querySelector(".decimal").addEventListener("click", addDecimal);
document.querySelector(".back").addEventListener("click", backspace);

function setOperator(op) {
  if (currentOperator !== null) evaluate();
  firstNumber = display.textContent;
  currentOperator = op;
  shouldResetDisplay = true;
}

function evaluate() {
  if (currentOperator === null || shouldResetDisplay) return;
  secondNumber = display.textContent;
  let result = operate(currentOperator, firstNumber, secondNumber);
  display.textContent = Math.round(result * 1000) / 1000;
  currentOperator = null;
}

function clear() {
  display.textContent = "0";
  firstNumber = "";
  secondNumber = "";
  currentOperator = null;
}

function addDecimal() {
  if (shouldResetDisplay) resetDisplay();
  if (!display.textContent.includes(".")) {
    display.textContent += ".";
  }
}

function backspace() {
  display.textContent = display.textContent.slice(0, -1) || "0";
}

function resetDisplay() {
  display.textContent = "";
  shouldResetDisplay = false;
}