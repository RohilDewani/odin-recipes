const myLibrary = [];

function Book(title, author, pages, read) {
  this.id = crypto.randomUUID(); // unique ID
  this.title = title;
  this.author = author;
  this.pages = pages;
  this.read = read;
}

// toggle read status on Book prototype
Book.prototype.toggleRead = function () {
  this.read = !this.read;
};

function addBookToLibrary(title, author, pages, read) {
  const book = new Book(title, author, pages, read);
  myLibrary.push(book);
  displayBooks();
}

function displayBooks() {
  const container = document.getElementById("bookContainer");
  container.innerHTML = ""; // clear old display

  myLibrary.forEach((book) => {
    const card = document.createElement("div");
    card.classList.add("card");
    card.dataset.id = book.id; // bind book with DOM element

    card.innerHTML = `
      <h3>${book.title}</h3>
      <p><strong>Author:</strong> ${book.author}</p>
      <p><strong>Pages:</strong> ${book.pages}</p>
      <p><strong>Status:</strong> ${book.read ? "Read" : "Not Read"}</p>
      <button class="toggleBtn">Toggle Read</button>
      <button class="removeBtn">Remove</button>
    `;

    // toggle button
    card.querySelector(".toggleBtn").addEventListener("click", () => {
      book.toggleRead();
      displayBooks();
    });

    // remove button
    card.querySelector(".removeBtn").addEventListener("click", () => {
      removeBook(book.id);
    });

    container.appendChild(card);
  });
}

function removeBook(id) {
  const index = myLibrary.findIndex((book) => book.id === id);
  if (index !== -1) {
    myLibrary.splice(index, 1);
    displayBooks();
  }
}

// form handling
const dialog = document.getElementById("bookDialog");
const newBookBtn = document.getElementById("newBookBtn");
const closeDialog = document.getElementById("closeDialog");
const bookForm = document.getElementById("bookForm");

newBookBtn.addEventListener("click", () => dialog.showModal());
closeDialog.addEventListener("click", () => dialog.close());

bookForm.addEventListener("submit", (e) => {
  e.preventDefault(); // stop form from refreshing page
  const title = document.getElementById("title").value;
  const author = document.getElementById("author").value;
  const pages = document.getElementById("pages").value;
  const read = document.getElementById("read").checked;

  addBookToLibrary(title, author, pages, read);
  bookForm.reset();
  dialog.close();
});
