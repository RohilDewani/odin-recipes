const Player = (name, marker) => {
  return { name, marker };
};

const Gameboard = (() => {
  const board = ["", "", "", "", "", "", "", "", ""];

  const getBoard = () => board;

  const setMark = (index, marker) => {
    if (board[index] === "") {
      board[index] = marker;
      return true;
    }
    return false;
  };

  const resetBoard = () => {
    for (let i = 0; i < board.length; i++) {
      board[i] = "";
    }
  };

  return { getBoard, setMark, resetBoard };
})();

const Game = (() => {
  let players = [];
  let currentPlayerIndex = 0;
  let gameOver = false;

  const start = (player1Name, player2Name) => {
    players = [Player(player1Name || "Player 1", "X"), Player(player2Name || "Player 2", "O")];
    currentPlayerIndex = 0;
    gameOver = false;
    Gameboard.resetBoard();
    DisplayController.renderBoard();
    DisplayController.updateResult("");
  };

  const checkWinner = () => {
    const b = Gameboard.getBoard();
    const winPatterns = [
      [0,1,2],[3,4,5],[6,7,8], // rows
      [0,3,6],[1,4,7],[2,5,8], // cols
      [0,4,8],[2,4,6]          // diagonals
    ];

    for (const pattern of winPatterns) {
      const [a, b1, c] = pattern;
      if (b[a] && b[a] === b[b1] && b[a] === b[c]) {
        gameOver = true;
        return players[currentPlayerIndex].name;
      }
    }

    if (!b.includes("")) {
      gameOver = true;
      return "Tie";
    }

    return null;
  };

  const playTurn = (index) => {
    if (gameOver) return;

    if (Gameboard.setMark(index, players[currentPlayerIndex].marker)) {
      DisplayController.renderBoard();
      const winner = checkWinner();
      if (winner) {
        DisplayController.updateResult(winner === "Tie" ? "It's a tie!" : `${winner} wins!`);
      } else {
        currentPlayerIndex = 1 - currentPlayerIndex;
      }
    }
  };

  return { start, playTurn };
})();

const DisplayController = (() => {
  const boardContainer = document.getElementById("gameboard");
  const resultContainer = document.getElementById("result");

  const renderBoard = () => {
    boardContainer.innerHTML = "";
    Gameboard.getBoard().forEach((mark, idx) => {
      const square = document.createElement("div");
      square.classList.add("square");
      square.textContent = mark;
      square.addEventListener("click", () => Game.playTurn(idx));
      boardContainer.appendChild(square);
    });
  };

  const updateResult = (text) => {
    resultContainer.textContent = text;
  };

  return { renderBoard, updateResult };
})();

document.getElementById("start-btn").addEventListener("click", () => {
  const p1 = document.getElementById("player1-name").value;
  const p2 = document.getElementById("player2-name").value;
  Game.start(p1, p2);
});

document.getElementById("restart-btn").addEventListener("click", () => {
  Game.start("Player 1", "Player 2");
});