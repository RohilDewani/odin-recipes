import Player from "./player.js";
import DisplayController from "./displayController.js";


const player1 = Player("Alice");
const player2 = Player("Computer", true);


player1.gameboard.placeShip(3, [[0,0],[0,1],[0,2]]);
player1.gameboard.placeShip(2, [[2,0],[2,1]]);
player2.gameboard.placeShip(3, [[5,5],[5,6],[5,7]]);
player2.gameboard.placeShip(2, [[7,0],[7,1]]);

const turn = { current: player1, opponent: player2 };


const takeTurn = (coord = null) => {
  let result;

  if (turn.current.isComputer) {
   
    result = turn.current.randomAttack(turn.opponent.gameboard);
    console.log(`${turn.current.name} attacks randomly: ${result}`);
  } else {
    
    if (!coord) return; 
    result = turn.current.attack(turn.opponent.gameboard, coord);
    console.log(`${turn.current.name} attacks ${coord}: ${result}`);
  }


  DisplayController.renderBoard(player1.gameboard, "player1-board");
  DisplayController.renderBoard(player2.gameboard, "player2-board", true, takeTurn);

  
  if (turn.opponent.gameboard.allShipsSunk()) {
    document.getElementById("game-status").textContent = `${turn.current.name} wins!`;
    return;
  }

  [turn.current, turn.opponent] = [turn.opponent, turn.current];

  
  if (turn.current.isComputer) {
    setTimeout(() => takeTurn(), 500);
  }
};

DisplayController.renderBoard(player1.gameboard, "player1-board");
DisplayController.renderBoard(player2.gameboard, "player2-board", true, takeTurn);