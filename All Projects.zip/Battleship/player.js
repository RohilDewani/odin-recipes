import Gameboard from "./gameboard.js";

const Player = (name, isComputer = false) => {
  const gameboard = Gameboard();

  const attack = (opponentBoard, coord) => {
    return opponentBoard.receiveAttack(coord);
  };

  const randomAttack = (opponentBoard) => {
    let x, y;
    do {
      x = Math.floor(Math.random() * 10);
      y = Math.floor(Math.random() * 10);
    } while (opponentBoard.missedAttacks.some(c => c[0] === x && c[1] === y));
    return attack(opponentBoard, [x, y]);
  };

  return { name, gameboard, attack, randomAttack, isComputer };
};

export default Player;