const DisplayController = (() => {

  const renderBoard = (board, containerId, isEnemy = false, attackCallback = null) => {
    const container = document.getElementById(containerId);
    container.innerHTML = "";

    for (let i = 0; i < 10; i++) {
      for (let j = 0; j < 10; j++) {
        const cell = document.createElement("div");
        cell.classList.add("cell");
        
        if (!isEnemy) {
          const shipObj = board.ships.find(obj =>
            obj.coordinates.some(c => c[0] === i && c[1] === j)
          );
          if (shipObj) cell.classList.add("ship");
        }

        const hitShip = board.ships.find(obj =>
          obj.coordinates.some(c => c[0] === i && c[1] === j && obj.ship.isSunk())
        );
        if (hitShip) cell.classList.add("hit");

        if (board.missedAttacks.some(c => c[0] === i && c[1] === j)) {
          cell.classList.add("miss");
        }

        if (isEnemy && attackCallback) {
          cell.addEventListener("click", () => attackCallback([i, j]));
        }

        container.appendChild(cell);
      }
    }
  };

  return { renderBoard };
})();

export default DisplayController;