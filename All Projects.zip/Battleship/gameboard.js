import Ship from "./ship.js";

const Gameboard = () => {
  const ships = [];
  const missedAttacks = [];

  const placeShip = (length, coordinates) => {
    const ship = Ship(length);
    ships.push({ ship, coordinates }); // coordinates = array of [x,y] pairs
  };

  const receiveAttack = (coord) => {
    for (let obj of ships) {
      for (let c of obj.coordinates) {
        if (c[0] === coord[0] && c[1] === coord[1]) {
          obj.ship.hit();
          return "hit";
        }
      }
    }
    missedAttacks.push(coord);
    return "miss";
  };

  const allShipsSunk = () => ships.every(obj => obj.ship.isSunk());

  return { ships, missedAttacks, placeShip, receiveAttack, allShipsSunk };
};

export default Gameboard;
