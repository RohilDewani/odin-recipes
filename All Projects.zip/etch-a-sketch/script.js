const container = document.getElementById("container");
const resetBtn = document.getElementById("resetBtn");

function createGrid(size) {
  container.innerHTML = "";
  const squareSize = 960 / size;

  for (let i = 0; i < size * size; i++) {
    const square = document.createElement("div");
    square.classList.add("square");
    square.style.width = `${squareSize}px`;
    square.style.height = `${squareSize}px`;

   
    square.addEventListener("mouseover", () => {
      square.style.backgroundColor = randomRGB(); 
      let opacity = parseFloat(square.style.opacity) || 0;
      if (opacity < 1) {
        opacity += 0.1;
        square.style.opacity = opacity; 
      }
    });
    container.appendChild(square);
  }
}

function randomRGB() {
  const r = Math.floor(Math.random() * 256);
  const g = Math.floor(Math.random() * 256);
  const b = Math.floor(Math.random() * 256);
  return `rgb(${r},${g},${b})`;
}

resetBtn.addEventListener("click", () => {
  let newSize = prompt("Enter new grid size (max 100):");
  newSize = parseInt(newSize);
  if (newSize && newSize > 0 && newSize <= 100) {
    createGrid(newSize);
  } else {
    alert("Please enter a number between 1 and 100.");
  }
});

createGrid(16);